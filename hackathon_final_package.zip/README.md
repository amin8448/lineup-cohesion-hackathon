# Lineup Cohesion: Network-Based Starting Eleven Optimization

**NEU Sports Analytics Hackathon 2026** — Prompt A (Starting Eleven)  
**Author:** Mohammad-Amin Nabavi  
**Contact:** nabavi@carleton.ca

---

## Key Results

| Metric | Value |
|--------|-------|
| Season correlation (cohesion vs points) | **r = 0.728*** (p = 0.0006) |
| Match-level ANOVA (win/draw/loss) | **F = 36.64*** (p < 0.0001) |
| Variance explained | **53%** |
| Key insight | Hub dependence > balance for elite teams |

---

## Research Question

Can we build a **network-based cohesion metric** that predicts match outcomes?

**Finding:** Elite teams funnel play through hub players (Xhaka, Kimmich). Star-dependent networks outperform balanced ones.

---

## Quick Start

```bash
# 1. Create virtual environment and install dependencies
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# 2. Run full analysis (processes all 306 Bundesliga matches)
cd notebooks
python 03_full_analysis.py

# 3. Re-validate with optimized weights
python 05_revalidate_optimized.py

# 4. Leverkusen case study
python 04_leverkusen_case_study.py
```

---

## Project Structure

```
Soccer analytics Hackathon/
├── data/                     # Generated results
│   ├── cohesion_results.csv
│   └── team_season_summary.csv
├── src/
│   └── cohesion_metric.py    # Core metric implementation
├── notebooks/
│   ├── 01_data_exploration.py   # Schema discovery
│   ├── 02_test_cohesion.py      # Quick test on sample match
│   ├── 03_full_analysis.py      # All 306 matches
│   ├── 04_leverkusen_case_study.py  # Deep dive
│   └── 05_revalidate_optimized.py   # Re-validation with optimized weights
├── figures/                  # Output visualizations
├── slides/                   # Presentation
├── requirements.txt
└── README.md
```

---

## Methodology

### Cohesion Score (Optimized Weights)

```
Cohesion = 0.50×Connectivity + 0.25×Chemistry + 0.15×Hub_Dependence + 0.10×Progression
```

| Component | Weight | Correlation | Description |
|-----------|--------|-------------|-------------|
| **Connectivity** | 50% | r = +0.785*** | Network density + clustering |
| **Chemistry** | 25% | r = +0.448* | Midfield→Attack connections |
| **Hub Dependence** | 15% | r = +0.714*** | Gini coefficient (star-reliance) |
| **Progression** | 10% | r = +0.133 | Pre-shot pass ratio |

### Key Innovation: Hub Dependence Paradox

Original hypothesis: Balanced teams (equal pass distribution) should win more.

**Actual finding:** Elite teams funnel play through hub players. After inverting "Balance" to "Hub Dependence", correlation improved from r=0.314 (not significant) to r=0.728 (p<0.001).

---

## Leverkusen Case Study

**Undefeated Season:** 28W, 6D, 0L | 90 points | 87 GF, 24 GA

Two hub types discovered:
- **Granit Xhaka** — Volume Hub: 558 passes with Palacios, recycles possession
- **Florian Wirtz** — Attack Hub: Highest betweenness (0.448), 22 pre-shot passes to Boniface

**The Killer Chain:** Xhaka → Wirtz → Boniface → GOAL

---

## Data

- **Source:** IMPECT Open Data via kloppy
- **Scope:** Bundesliga 2023/24 (306 matches, 18 teams)
- **Limitations:** ~24% passes lack receiver ID; single season

---

## AI Disclosure

Claude (Anthropic) assisted with code development, data analysis, and slide formatting.

---

## License

MIT License

Data: IMPECT Open Data - Non-commercial use only
